# ELSAfrailty

## :books: Overview :books:
Rocking up with different ML methods to look at predictors of frailty in the UK using the ELSA wave 8 (for now) dataset.

## :hammer_and_wrench: Prerequisites :hammer_and_wrench:
- Python 3.x
- Required Python packages: 'pandas', 'numpy', 


## :rocket: What has been done so far :rocket:
1. Categorize participants based on fraily status (n = 3180)<br>
             Wave 6      Wave 8 <br>
non-frail     1490          1406 <br>
pre-frail     1616          1646 <br>
frail              74            128 <br>


## :rocket: What needs to be done :rocket:
Preprocessing
1. Extract relevant data from potential predictor variables
2. Naturally, use the primary key "idauniq" to reduce the df of this new df.
3. Remove all frailty values (and the ones that could also be used, but we didn't use. (e.g., BMIcat)
4. Figure out what variables to include. Determine missingness
Machine Learning EDA
5. Balance data SMOTE?
6. multiple imputation by chained equations (MICE)?

## How to run
Steps:
1. You need one h_elsa_g3.tab file put in the tab folder in the project
2. You need to install python packages which I will put in the requirements.txt
3. You can use the elsawave6and8_frailtycategorization.py to preprocess the raw data as well as 
extract some of the parameters.
