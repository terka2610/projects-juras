import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from catboost import CatBoostClassifier
from imblearn.over_sampling import SMOTE
from lightgbm import LGBMClassifier
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, auc, balanced_accuracy_score, classification_report, 
    confusion_matrix, ConfusionMatrixDisplay, f1_score, precision_score, 
    recall_score, roc_curve, roc_auc_score
)
from sklearn.model_selection import (
    KFold, train_test_split, GridSearchCV
)
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelBinarizer, LabelEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from itertools import cycle

import warnings
warnings.filterwarnings('ignore')

pd.set_option('display.max_rows', None)


# Ensure reproducibility
random_state = 42

# Load data
df = pd.read_csv("/Users/AHMS/Documents/Python Scripts/wave8_readyforML_3class.csv")

# Drop the 'idauniqc' column if it exists
if 'idauniqc' in df.columns:
    df = df.drop(columns=['idauniqc'])
    print("'idauniqc' column dropped.")
else:
    print("'idauniqc' column not found in the DataFrame.")

# Drop columns with high missing values
threshold_col = len(df) * 0.30
df_cleaned = df.dropna(axis=1, thresh=int(len(df) - threshold_col))

# Drop low variance features
variances = df_cleaned.var()
threshold = 0.01
low_variance_features = variances[variances < threshold].index
df_cleaned_low_variance = df_cleaned.drop(columns=low_variance_features)

# Drop highly correlated features
correlation_matrix = df_cleaned_low_variance.corr().abs()
mask = np.triu(correlation_matrix > 0.80, k=1)
to_drop_corr = [column for column in correlation_matrix.columns if any(mask[correlation_matrix.columns.get_loc(column)]) and column != 'r8agey']
df_reduced_corr = df_cleaned_low_variance.drop(columns=to_drop_corr)

# Perform Little's MCAR test
from scipy.stats import chi2

def little_mcar_test(df):
    df_nonan = df.dropna(how='all')
    if df_nonan.empty:
        return {'chi_square': np.nan, 'p_value': np.nan, 'degrees_of_freedom': np.nan}
    missing_pattern = df_nonan.isnull().astype(int)
    pattern_counts = missing_pattern.groupby(missing_pattern.sum(axis=1).astype(str)).size()
    if pattern_counts.empty:
        return {'chi_square': np.nan, 'p_value': np.nan, 'degrees_of_freedom': np.nan}
    
    observed_freq = pattern_counts.values
    expected_freq = np.full_like(observed_freq, fill_value=np.mean(observed_freq))
    expected_freq[expected_freq <= 0] = 1e-10
    chi_square_stat = np.sum((observed_freq - expected_freq) ** 2 / expected_freq)
    degrees_of_freedom = len(observed_freq) - 1
    p_value = chi2.sf(chi_square_stat, df=degrees_of_freedom)
    return {'chi_square': chi_square_stat, 'p_value': p_value, 'degrees_of_freedom': degrees_of_freedom}

result = little_mcar_test(df_reduced_corr)
print(f"Chi-square: {result['chi_square']}, p-value: {result['p_value']}, degrees of freedom: {result['degrees_of_freedom']}")

# Visualize missing data
import missingno as msno
msno.matrix(df_reduced_corr)

# Handle missing values
threshold_row = len(df_reduced_corr.columns) * 0.30
df_cleaned1 = df_reduced_corr.dropna(axis=0, thresh=int(len(df_reduced_corr.columns) - threshold_row))
imputer = IterativeImputer(random_state=random_state)
df_imputed = imputer.fit_transform(df_cleaned1)
df_imputed = pd.DataFrame(df_imputed, columns=df_cleaned1.columns)

# Visualize imputed data
msno.matrix(df_imputed)

# Remove high VIF features
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm

def remove_high_vif_features(df, threshold=5, keep_columns=['r8agey']):
    X = df.copy()
    while True:
        X_with_const = sm.add_constant(X)
        vif = pd.DataFrame()
        vif['Feature'] = X_with_const.columns
        vif['VIF'] = [variance_inflation_factor(X_with_const.values, i) for i in range(X_with_const.shape[1])]
        vif = vif[vif['Feature'] != 'const']
        high_vif_features = vif[(vif['VIF'] > threshold) & (~vif['Feature'].isin(keep_columns))]['Feature'].tolist()
        if not high_vif_features:
            break
        feature_to_remove = vif.loc[vif['VIF'].idxmax(), 'Feature']
        print(f"Removing feature: {feature_to_remove} with VIF: {vif['VIF'].max()}")
        X = X.drop(columns=feature_to_remove)
    return X

df_cleaned = remove_high_vif_features(df_imputed, threshold=5, keep_columns=['r8agey'])
print("DataFrame shape after dropping high VIF:", df_cleaned.shape)

df_cleaned.to_csv('wave8_checkforcontinuousvariables_3kfold.csv', index=False)


# Split and preprocess data
continuous_vars = ['r8smokef', 'r8tr20','r8verbf','r8issdi','r8isret','r8igxfr','r8dau','r8son','r8retage','r8liv10','r8liv10a',
                   'r8pnhm5y','r8mweight','r8gcarehpw','r8gcaresckhpw','r8cantril','r8casp12']
categorical_vars = [col for col in df_cleaned.columns if col not in continuous_vars and col != 'frail_cat1']

# Define X and y
X = df_cleaned.drop(columns=['frail_cat1'])
y = df_cleaned['frail_cat1']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=random_state)

# Apply SMOTE to the training set only
smote_train = SMOTE(random_state=random_state)
X_train_resampled, y_train_resampled = smote_train.fit_resample(X_train, y_train)

# Print class distribution before and after SMOTE
print(f"Train class distribution:\n{y_train_resampled.value_counts()}")
print(f"Test class distribution:\n{y_test.value_counts()}")


# Separate continuous and categorical variables for train and test sets
X_train_continuous = X_train_resampled[continuous_vars]
X_train_categorical = X_train_resampled[categorical_vars]
X_test_continuous = X_test[continuous_vars]
X_test_categorical = X_test[categorical_vars]

# Scale the continuous variables
scaler = StandardScaler()
X_train_continuous_scaled = pd.DataFrame(scaler.fit_transform(X_train_continuous), columns=continuous_vars)
X_test_continuous_scaled = pd.DataFrame(scaler.transform(X_test_continuous), columns=continuous_vars)

# Recombine the scaled continuous variables with the categorical variables
X_train_final = pd.concat([X_train_continuous_scaled, X_train_categorical.reset_index(drop=True)], axis=1)
X_test_final = pd.concat([X_test_continuous_scaled, X_test_categorical.reset_index(drop=True)], axis=1)

# Feature Selection using SelectFromModel
rf = RandomForestClassifier(n_jobs=-1, class_weight='balanced', random_state=random_state)
rf.fit(X_train_final, y_train_resampled)

# Use SelectFromModel for feature selection
from sklearn.feature_selection import SelectFromModel
selector = SelectFromModel(rf, threshold='mean', prefit=True)

# Get the selected features
X_train_selected = selector.transform(X_train_final)
X_test_selected = selector.transform(X_test_final)

# Get feature names
selected_features = X_train_final.columns[selector.get_support()]

# Print selected features
print("Selected features:")
for feature in selected_features:
    print(feature)

# Print the shape of the datasets after feature selection
print(f"Shape of X_train_selected: {X_train_selected.shape}")
print(f"Shape of X_test_selected: {X_test_selected.shape}")

#X_train_selected
#X_test_selected
#y_train_resampled
#y_test

############################################################################################
############################################################################################
# Define the models
models = {
    'Logistic Regression': LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=1000, random_state=42),
    'Support Vector Classifier': SVC(probability=True, random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
    'K-Nearest Neighbors': KNeighborsClassifier(),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42),
    'AdaBoost': AdaBoostClassifier(random_state=42),
    'XGBoost': XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42),
    'LightGBM': LGBMClassifier(random_state=42),
    'CatBoost': CatBoostClassifier(verbose=0, random_state=42),
    'Neural Network': MLPClassifier(max_iter=1000, random_state=42),
}

def evaluate_model(model, X, y, n_splits=10, random_state=None):
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    all_fpr = np.linspace(0, 1, 100)
    tprs = {i: np.zeros_like(all_fpr) for i in range(len(set(y)))}
    auc_scores = []

    lb = LabelBinarizer()
    y_bin = lb.fit_transform(y)
    num_classes = y_bin.shape[1]

    for train_index, test_index in kf.split(X):
        X_train_cv, X_test_cv = X.iloc[train_index], X.iloc[test_index]
        y_train_cv, y_test_cv = y.iloc[train_index], y.iloc[test_index]
        
        model.fit(X_train_cv, y_train_cv)
        y_pred_proba = model.predict_proba(X_test_cv)

        for i in range(num_classes):
            fpr, tpr, _ = roc_curve(y_test_cv == i, y_pred_proba[:, i])
            roc_auc = auc(fpr, tpr)
            auc_scores.append(roc_auc)
            tprs[i] += np.interp(all_fpr, fpr, tpr)
            tprs[i][0] = 0.0

    for i in tprs:
        tprs[i] /= n_splits
    
    mean_tpr = np.mean(list(tprs.values()), axis=0)
    mean_auc = np.mean(auc_scores)

    return tprs, all_fpr, mean_tpr, mean_auc, auc_scores

def evaluate_and_print_metrics(models, X_train_selected, y_train_resampled, X_test_selected, y_test):
    metrics = {
        'Accuracy': [],
        'Precision': [],
        'Recall': [],
        'F1 Score': [],
        'Balanced Accuracy': [],
        'Classification Report': [],
        'Confusion Matrix': [],
        'ROC Curve': {},
        'ROC AUC': {},
        'Macro-average ROC AUC': [],
        'Macro-average ROC Curve': {}
    }
    
    for model_name, model in models.items():
        print(f"\nEvaluating {model_name}...")
        
        model.fit(pd.DataFrame(X_train_selected), y_train_resampled)
        y_pred = model.predict(pd.DataFrame(X_test_selected))
        y_pred_proba = model.predict_proba(pd.DataFrame(X_test_selected))
        
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')
        recall = recall_score(y_test, y_pred, average='weighted')
        f1 = f1_score(y_test, y_pred, average='weighted')
        balanced_acc = balanced_accuracy_score(y_test, y_pred)

        report = classification_report(y_test, y_pred, target_names=['Frail', 'Pre-Frail', 'Non-Frail'])
        metrics['Classification Report'].append((model_name, report))
        
        cm = confusion_matrix(y_test, y_pred, labels=[0, 1, 2])
        metrics['Confusion Matrix'].append((model_name, cm))
        
        lb = LabelBinarizer()
        y_bin = lb.fit_transform(y_test)
        num_classes = y_bin.shape[1]

        all_fpr = np.linspace(0, 1, 100)
        tprs = {}
        auc_scores = []

        for i in range(num_classes):
            fpr, tpr, _ = roc_curve(y_bin[:, i], y_pred_proba[:, i])
            roc_auc = auc(fpr, tpr)
            auc_scores.append(roc_auc)
            tprs[i] = np.interp(all_fpr, fpr, tpr)
            tprs[i][0] = 0.0

        mean_tpr = np.mean(np.array(list(tprs.values())), axis=0)
        mean_tpr[0] = 0.0
        macro_auc = np.mean(auc_scores)
        
        metrics['Accuracy'].append((model_name, round(accuracy, 3)))
        metrics['Precision'].append((model_name, round(precision, 3)))
        metrics['Recall'].append((model_name, round(recall, 3)))
        metrics['F1 Score'].append((model_name, round(f1, 3)))
        metrics['Balanced Accuracy'].append((model_name, round(balanced_acc, 3)))
        metrics['ROC Curve'][model_name] = (all_fpr, tprs)
        metrics['ROC AUC'][model_name] = round(macro_auc, 3)
        metrics['Macro-average ROC Curve'][model_name] = (all_fpr, mean_tpr)
        metrics['Macro-average ROC AUC'].append((model_name, round(macro_auc, 3)))

    # Print metrics organized by metric type
    print("\nMetrics Summary:\n")

    # Accuracy
    print("Accuracy:")
    for model_name, acc in metrics['Accuracy']:
        print(f"{model_name}: {acc}")
    
    # Balanced Accuracy
    print("\nBalanced Accuracy:")
    for model_name, bal_acc in metrics['Balanced Accuracy']:
        print(f"{model_name}: {bal_acc}")
    
    # Precision
    print("\nPrecision:")
    for model_name, prec in metrics['Precision']:
        print(f"{model_name}: {prec}")
    
    # Recall
    print("\nRecall:")
    for model_name, rec in metrics['Recall']:
        print(f"{model_name}: {rec}")
    
    # F1 Score
    print("\nF1 Score:")
    for model_name, f1 in metrics['F1 Score']:
        print(f"{model_name}: {f1}")
    
    # Classification Report
    print("\nClassification Report:")
    for model_name, report in metrics['Classification Report']:
        print(f"\n{model_name}:\n{report}")
    
    # ROC AUC
    print("\nROC AUC Scores per Model:")
    for model_name, auc_score in metrics['ROC AUC'].items():
        print(f"{model_name}: {auc_score}")
    
    # Macro-average ROC AUC
    print("\nMacro-average ROC AUC:")
    for model_name, macro_auc in metrics['Macro-average ROC AUC']:
        print(f"{model_name}: {macro_auc}")

# Evaluate models
results = {}
for model_name, model in models.items():
    print(f"\nEvaluating {model_name}...")
    tprs, all_fpr, mean_tpr, mean_auc, auc_scores = evaluate_model(model, pd.DataFrame(X_train_selected), y_train_resampled)
    results[model_name] = {
        'TPRs': tprs,
        'Mean FPR': all_fpr,
        'Mean TPR': mean_tpr,
        'Mean AUC': mean_auc,
        'AUC Scores': auc_scores
    }

# Plot ROC Curves in a 2x5 grid
fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(20, 10), sharex=True, sharey=True)
axes = axes.flatten()

for i, (model_name, metrics) in enumerate(results.items()):
    ax = axes[i]
    
    # Plot ROC curves for each class
    for class_index, class_name in enumerate(['Frail', 'Pre-Frail', 'Non-Frail']):
        if class_index in metrics['TPRs']:
            fpr = metrics['Mean FPR']
            tpr = metrics['TPRs'][class_index]
            auc_score = metrics['AUC Scores'][class_index]
            
            ax.plot(fpr, tpr, lw=2, label=f'{class_name} (AUC = {auc_score:.2f})')

    # Plot macro-average ROC curve
    ax.plot(metrics['Mean FPR'], metrics['Mean TPR'], linestyle='--', color='gray', lw=2, 
            label=f'Macro-average (AUC = {metrics["Mean AUC"]:.2f})')
    
    # Plot the diagonal line
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    
    # Set axis limits
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    
    # Set labels and title
    ax.set_xlabel('False Positive Rate')
    ax.set_ylabel('True Positive Rate')
    ax.set_title(model_name)
    ax.legend(loc='lower right')

plt.tight_layout()
plt.show()

# Plot Confusion Matrices in a 2x5 grid
fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(20, 10), sharex=True, sharey=True)
axes = axes.flatten()

for i, (model_name, model) in enumerate(models.items()):
    ax = axes[i]
    model.fit(pd.DataFrame(X_train_selected), y_train_resampled)
    y_pred = model.predict(pd.DataFrame(X_test_selected))
    
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1, 2])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Frail', 'Pre-Frail', 'Non-Frail'])
    disp.plot(ax=ax, cmap=plt.cm.Blues, colorbar=False)
    ax.set_title(f'Confusion Matrix for {model_name}')

plt.tight_layout()
plt.show()

# Print metrics
evaluate_and_print_metrics(models, X_train_selected, y_train_resampled, X_test_selected, y_test)


############################################################################################
############################################################################################
# STEP 5: GRID SEARCH (LIKE A MOTHER)


param_grids = {
    'Logistic Regression': {
        'C': [0.001, 0.01, 0.1, 1, 10, 100],
        'penalty': ['l1', 'l2'],
        'solver': ['liblinear', 'saga']
    },
    'Support Vector Classifier': {
        'C': [0.001, 0.01, 0.1, 1, 10, 100],
        'kernel': ['linear', 'poly', 'rbf', 'sigmoid'],
        'degree': [2, 3, 4],
        'gamma': ['scale', 'auto']
    },
    'Random Forest': {
        'n_estimators': [50, 100, 200, 300],
        'max_depth': [None, 10, 20, 30, 40],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'bootstrap': [True, False]
    },
    'K-Nearest Neighbors': {
        'n_neighbors': [3, 5, 7, 10],
        'weights': ['uniform', 'distance'],
        'p': [1, 2]
    },
    'Gradient Boosting': {
        'n_estimators': [50, 100, 200],
        'learning_rate': [0.001, 0.01, 0.1, 0.2],
        'max_depth': [3, 5, 7],
        'subsample': [0.8, 0.9, 1.0]
    },
    'AdaBoost': {
        'n_estimators': [50, 100, 200],
        'learning_rate': [0.001, 0.01, 0.1, 1]
    },
    'XGBoost': {
        'n_estimators': [50, 100, 200],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [3, 5, 7],
        'subsample': [0.8, 0.9, 1.0],
        'colsample_bytree': [0.8, 0.9, 1.0],
        'gamma': [0, 0.1, 0.2]
    },
    'LightGBM': {
        'n_estimators': [50, 100, 200],
        'learning_rate': [0.001, 0.01, 0.1, 0.2],
        'max_depth': [-1, 10, 20, 30],
        'num_leaves': [31, 63, 127],
        'boosting_type': ['gbdt', 'dart', 'goss']
    },
    'CatBoost': {
        'iterations': [50, 100, 200],
        'learning_rate': [0.01, 0.1, 0.2],
        'depth': [6, 8, 10],
        'l2_leaf_reg': [1, 3, 5]
    },
    'Neural Network': {
        'hidden_layer_sizes': [(50,), (100,), (50, 50), (100, 50)],
        'activation': ['relu', 'tanh', 'logistic'],
        'solver': ['adam', 'sgd'],
        'alpha': [0.0001, 0.001, 0.01],
        'learning_rate': ['constant', 'adaptive']
    }
}

# Grid search function
def perform_grid_search(X_train, y_train, models, param_grids, cv=10):
    best_params = {}
    best_scores = {}
    best_models = {}
    
    for model_name, model in models.items():
        print(f"Performing grid search for {model_name}...")
        param_grid = param_grids[model_name]
        
        # GridSearchCV initialization
        grid_search = GridSearchCV(estimator=model, param_grid=param_grid, 
                                   scoring='accuracy', cv=cv, 
                                   n_jobs=-1, verbose=1)
        
        # Fit GridSearchCV
        grid_search.fit(X_train, y_train)
        
        # Store the best parameters and best score
        best_params[model_name] = grid_search.best_params_
        best_scores[model_name] = grid_search.best_score_
        best_models[model_name] = grid_search.best_estimator_
        
        print(f"Best parameters for {model_name}: {grid_search.best_params_}")
        print(f"Best accuracy for {model_name}: {grid_search.best_score_:.3f}\n")
    
    return best_params, best_scores, best_models

# Function to evaluate the best models
def evaluate_best_models(X_test, y_test, best_models):
    results = {}
    confusion_matrices = {}
    roc_curves = {}
    n_classes = len(np.unique(y_test))
    
    for model_name, model in best_models.items():
        # Predict
        y_pred = model.predict(X_test)
        
        # Ensure y_prob is correctly computed
        if hasattr(model, "predict_proba"):
            y_prob = model.predict_proba(X_test)
        else:
            y_prob = model.decision_function(X_test)
        
        # Metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')
        recall = recall_score(y_test, y_pred, average='weighted')
        f1 = f1_score(y_test, y_pred, average='weighted')
        balanced_acc = balanced_accuracy_score(y_test, y_pred)
        roc_auc = roc_auc_score(y_test, y_prob, multi_class='ovo', average='macro')
        
        results[model_name] = {
            'Accuracy': accuracy,
            'Precision': precision,
            'Recall': recall,
            'F1 Score': f1,
            'Balanced Accuracy': balanced_acc,
            'ROC AUC': roc_auc
        }
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        confusion_matrices[model_name] = cm
        
        # Compute ROC curve and AUC for each class
        fpr = dict()
        tpr = dict()
        roc_auc_classes = dict()
        for i in range(n_classes):
            fpr[i], tpr[i], _ = roc_curve(y_test, y_prob[:, i], pos_label=i)
            roc_auc_classes[i] = roc_auc_score(y_test == i, y_prob[:, i])
        
        # Compute micro-average ROC curve and ROC area
        all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
        mean_tpr = np.zeros_like(all_fpr)
        for i in range(n_classes):
            mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
        mean_tpr /= n_classes
        
        roc_curves[model_name] = {
            'fpr': fpr,
            'tpr': tpr,
            'roc_auc_classes': roc_auc_classes,
            'macro_fpr': all_fpr,
            'macro_tpr': mean_tpr,
            'macro_auc': roc_auc
        }
    
    return results, confusion_matrices, roc_curves

# Assuming you have already defined models and param_grids
# Call the grid search function
best_params, best_scores, best_models = perform_grid_search(X_train_selected, y_train_resampled, models, param_grids)

# Evaluate the best models
results, confusion_matrices, roc_curves = evaluate_best_models(X_test_selected, y_test, best_models)

# Print the results
for model_name, metrics in results.items():
    print(f"\nModel: {model_name}")
    for metric_name, value in metrics.items():
        print(f"{metric_name}: {value:.4f}")

# Check the lengths again if there are issues
print(f"Length of y_test: {len(y_test)}")
print(f"Length of y_prob for each model:")
for model_name, model in best_models.items():
    if hasattr(model, "predict_proba"):
        y_prob = model.predict_proba(X_test_selected)[:, 1]
    else:
        y_prob = model.decision_function(X_test_selected)
    print(f"{model_name}: {len(y_prob)}")

# Print metrics
metrics_list = ['Accuracy', 'Precision', 'Recall', 'F1 Score', 'Balanced Accuracy', 'ROC AUC']
for metric in metrics_list:
    print(f"\n{metric} for all models:")
    for model_name, metrics in results.items():
        print(f"{model_name}: {metrics[metric]:.3f}")

# Plot confusion matrices
num_models = len(confusion_matrices)
fig_cm, axes_cm = plt.subplots(nrows=2, ncols=5, figsize=(20, 8))
fig_cm.suptitle('Confusion Matrices')

for i, (model_name, cm) in enumerate(confusion_matrices.items()):
    row_cm, col_cm = divmod(i, 5)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=np.unique(y_test))
    disp.plot(cmap=plt.cm.Blues, ax=axes_cm[row_cm, col_cm], colorbar=False)
    axes_cm[row_cm, col_cm].set_title(f'{model_name}')
    axes_cm[row_cm, col_cm].set_xlabel('Predicted')
    axes_cm[row_cm, col_cm].set_ylabel('Actual')

for j in range(num_models, 10):
    fig_cm.delaxes(axes_cm[j // 5, j % 5])

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

# Plot ROC Curves in a 2x5 grid
fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(20, 10), sharex=True, sharey=True)
axes = axes.flatten()

for i, (model_name, roc_data) in enumerate(roc_curves.items()):
    ax = axes[i]
    fpr = roc_data['fpr']
    tpr = roc_data['tpr']
    roc_auc_classes = roc_data['roc_auc_classes']
    macro_fpr = roc_data['macro_fpr']
    macro_tpr = roc_data['macro_tpr']
    macro_auc = roc_data['macro_auc']
    
    for class_index in range(len(fpr)):
        ax.plot(fpr[class_index], tpr[class_index], lw=2, label=f'Class {class_index} (AUC = {roc_auc_classes[class_index]:.2f})')
    
    ax.plot(macro_fpr, macro_tpr, color='black', linestyle='--', lw=2, label=f'Macro-average (AUC = {macro_auc:.2f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel('False Positive Rate')
    ax.set_ylabel('True Positive Rate')
    ax.set_title(f'ROC Curve - {model_name}')
    ax.legend(loc='lower right')

for j in range(len(best_models), 10):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()
