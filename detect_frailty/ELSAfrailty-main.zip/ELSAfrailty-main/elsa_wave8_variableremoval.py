import pandas as pd
import re

############################################################################################
# Load Data
file_path = "C:/Users/AHMS/Documents/Python Scripts/h_elsa_g3.tab"

# Attempting to read the .tab file
try:
    df = pd.read_csv(file_path, sep='\t')
    print(df.head())
except Exception as e:
    print("Cannot read tab file:", e)

# Convert all values to numeric, forcing errors to NaN
df = df.apply(pd.to_numeric, errors='coerce')

# Remove rows where 'r8agey' is less than 50 or missing
df1 = df[(df['r8agey'] >= 50) & (df['r8agey'].notna())]
df1 = df1.reset_index(drop=True)

print("Original df:\n", df.shape)
print("Over 50 only:\n", df1.shape)

#################### Remove irrelevant variable possibilities
# List of substrings to search for
substrings_to_remove = ['iwstat', 'cohort', 'samp', 'clust', 'strat', 'resp', 'oeret', 'wrk', 'mom',
                        'dad', 'mamm', 'pena', 'stat', 'tresp', 'fin', 'hhr', 'hor', 'proxy', 'win', 'nrs',
                        'rab', 'year', 'raf', 'endr', 'edyr', 'mpart', 'mrc', 'mnev', 'mdiv', 'mwid', 'mend',
                        'mcurl', 'mlen', 'place', 'country', 'mliv', 'shlta', 'dress', 'walk', 'bath', 'eate',
                        'bed', 'toil', 'money', 'shop', 'med', 'hsw', 'mapa', 'phone', 'meal', 'house', 'dang',
                        'commu', 'sit', 'chair', 'clim', 'stoop', 'lift', 'dime', 'arms', 'push', 'wam', 'c2',
                        'lam', 'five', 'tot', 'four', 'mobil', 'mus', 'nagi', 'hys', 'nspd', 'pros', 'hpsr', 'hilt',
                        'r8beq50p', 'bpen', 'ram', 'rad', 'lifeinv', 'racc', 'rach', 'dias', 'systo', 'puls','beq',
                        'warmm','ortm','speed','mbmi','grip','gactx','mdac','effor','goin','ifss','child','racs',
                        'raspct','ivsib','r8drink','prv','outcon','lft','stp','msht','free','cand','sslf','look',
                        'look','futre','cmpn','shap','energ','snth','opp','domhand','ifgxfr','sust','critz','letd',
                        'getn','dema','rely','open','ustd','lfemean','enjd','happ','plsr','cntr','auto','slfr',
                        'deal','lex','lsts','limp','chnot','comp','left','isol','intun'
                        ]

# List of prefixes to search for
prefixes_to_remove = ['hh', 'h', 'int', 'raspid', 'inw']

# Filter out columns that contain any of the substrings or start with any of the prefixes
columns_to_keep = [
    col for col in df1.columns
    if not any(substring in col for substring in substrings_to_remove) and
       not any(col.startswith(prefix) for prefix in prefixes_to_remove)
]

# Create a new DataFrame with only the columns to keep
df2 = df1[columns_to_keep]

print("Minus substring and variables:\n", df2.shape)

####

#### 
# Step X: Remove respondent variables from other waves
def remove_specific_columns(df):
    """
    Remove columns from a DataFrame that start with 'r' and a number (unless it's 'r8'), 'h', 'hh', 'inw',
    or 's' followed by a number (unless it's 's8').
    
    Parameters:
    df (pd.DataFrame): The input DataFrame from which to remove columns.
    
    Returns:
    pd.DataFrame: The DataFrame with the specified columns removed.
    """
    def should_remove(column_name):
        if re.match(r'^r\d', column_name) and not column_name.startswith('r8'):
            return True
        if column_name.startswith('h') or column_name.startswith('hh') or column_name.startswith('inw'):
            return True
        if re.match(r'^s\d', column_name) and column_name != 's8':
            return True
        return False

    # Filter out the columns that match the criteria
    columns_to_remove = [col for col in df.columns if should_remove(col)]
    
    # Drop the specified columns
    df_filtered = df.drop(columns=columns_to_remove)
    
    return df_filtered

df4 = remove_specific_columns(df2)

print("Minus spouse and other wave variables:\n", df4.shape)

#Save as CSV for EDA and Pre-processing
df4.to_csv('wave8_cleaneddata.csv', index=False)
