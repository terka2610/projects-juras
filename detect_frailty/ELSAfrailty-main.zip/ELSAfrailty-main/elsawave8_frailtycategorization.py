#ELSA Wave 8
#5050_harmonized_elsa_g3_2002-2019

#Packages
import pandas as pd
import numpy as np

import warnings
warnings.filterwarnings('ignore')

pd.set_option('display.max_rows', None)

############################################################################################
#Load Data
file_path = "C:/Users/AHMS/Documents/Python Scripts/h_elsa_g3.tab"

# Attempting to read the .tab file
try:
    df = pd.read_csv(file_path, sep='\t')
    print(df.head())
except Exception as e:
    print("You are a loser. Can\t read tab file:", e)

df.shape

############################################################################################

#Reduce df
df_frailty = df.loc[:, ['idauniq', 'ragender',
                        'r8mbmi',
                        'r8rgrip',
                        'r8wspeed',
                        'r8vgactx_e', 'r8mdactx_e',
                        'r8effort', 'r8going']].copy()

df_frailty_stats = df_frailty.describe()

#columns of NaN values
nan_percentage = df_frailty.isnull().sum() / len(df_frailty) * 100
print(nan_percentage)

# Replace empty strings with NaN
df_frailty.replace(" ", np.nan, inplace=True)

#Change columns to numeric
object_cols = df_frailty.select_dtypes(include=['object']).columns

for col in object_cols:
    try:
        df_frailty[col] = pd.to_numeric(df_frailty[col])
    except ValueError:
        print(f"Unable to convert column {col} to numeric.")

print(df_frailty.dtypes)

#Remove stupid values from exhaustion-based columns
df_cleaned = df_frailty[(df_frailty['r8effort'].isin([0, 1])) & (df_frailty['r8going'].isin([0, 1]))]

# Counting NaN values in all columns
nan_count = df_cleaned.isna().sum()
print(nan_count)

#Drop Missing Values
df_cleaned = df_cleaned.dropna()
print(df_cleaned)


############################################################################################
#Time to calculate frailty!

#Grip Strength
quintiles = df_cleaned.groupby('ragender')['r8rgrip'].transform(lambda x: pd.qcut(x, q=5, labels=False, duplicates='drop'))
df_cleaned['weakness'] = (quintiles == 0).astype(int) # Create a new column to indicate if each value is in the lowest quintile (1) or not (0)

#Walking Speed:  Calculate quintiles of r8wspeed stratified by ragender
quintiles = df_cleaned.groupby('ragender')['r8wspeed'].transform(lambda x: pd.qcut(x, q=5, labels=False, duplicates='drop'))
df_cleaned['walkingspeed'] = (quintiles == 0).astype(int) # Create a new column to indicate if each value is in the lowest quintile (1) or not (0)

#Weight Loss
df_cleaned['weightloss'] = df_cleaned['r8mbmi'].apply(lambda x: 1 if x < 18.5 else 0)

#Low PA
df_cleaned['lowpa'] = df_cleaned.apply(lambda row: 1 if (row['r8vgactx_e'] == 5 and row['r8mdactx_e'] == 5) else 0, axis=1)

#Exhaustion
df_cleaned['exhaustion'] = df_cleaned.apply(lambda row: 1 if row['r8effort'] == 1 or row['r8going'] == 1 else 0, axis=1)


############################################################################################
#Make new df with just the Fried Criterion values
selected_columns = ['idauniq','weakness','walkingspeed', 'weightloss', 'lowpa','exhaustion']

fried_criteria_wave8 = df_cleaned[selected_columns].copy()
print(fried_criteria_wave8)

# Sum the specified columns
fried_criteria_wave8['frail_sum'] = fried_criteria_wave8[['weakness','walkingspeed', 'weightloss', 'lowpa','exhaustion']].sum(axis=1)

# Define the categorization function
def categorize_frailty(score):
    if score == 0:
        return 'non-frail'
    elif score in [1, 2]:
        return 'pre-frail'
    elif score >= 3:
        return 'frail'
    else:
        return 'unknown'

# Apply the categorization function to create the 'frail_cat' column
fried_criteria_wave8['frail_cat'] = fried_criteria_wave8['frail_sum'].apply(categorize_frailty)

# Count the occurrences of each category in the 'frail_cat' column
frail_cat_counts = fried_criteria_wave8['frail_cat'].value_counts()
print("Counts of each category in 'frail_cat':")
print(frail_cat_counts)

# Specify the full file path where you want to save the DataFrame
file_path = "C:/Users/AHMS/Documents/Python Scripts/fried_criteria_wave8.csv"
fried_criteria_wave8.to_csv(file_path, index=False)
