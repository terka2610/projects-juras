"""Thresholding functions for CompFS."""

# Third-party imports
import torch


def make_lambda_threshold(lmd):
    """Create a lambda threshold function.

    Args:
        lmd (float): The threshold value.

    Returns:
        Callable: A threshold function that returns 1 if the value is above the threshold, otherwise 0.
    """
    lmd = float(lmd)

    def l_func(p):
        return p >= torch.full_like(p, lmd)

    return l_func


def make_std_threshold(nsigma):
    """Create a standard deviation threshold function.

    Args:
        nsigma (float): The number of standard deviations.

    Returns:
        Callable: A threshold function that returns 1 if the value is above the mean plus n standard deviations, otherwise 0.
    """
    nsigma = float(nsigma)

    def std_dev_func(p):
        mean = torch.mean(p)
        std = torch.std(p)
        return p >= torch.full_like(p, (mean + nsigma * std).item())

    return std_dev_func


def make_top_k_threshold(k):
    """Create a top k threshold function.

    Args:
        k (int): The number of top features to choose.

    Returns:
        Callable: A threshold function that chooses the top k features.
    """
    k = int(k)

    def top_k(p):
        ids = torch.topk(p, k)[1]
        out = torch.zeros_like(p)
        out[ids] = 1.0
        return out.int()

    return top_k
