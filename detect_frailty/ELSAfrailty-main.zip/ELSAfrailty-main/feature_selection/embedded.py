from typing import List
from pandas import DataFrame
from sklearn.base import ClassifierMixin
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.tree import DecisionTreeClassifier
from enum import Enum

from utils import split_train_test, read_csv, update


class ModelType(Enum):
    """Enumeration for model types."""
    RF = "rf"
    GBT = "gbt"
    DT = "dt"


class Embedded:
    """
    Embedded Models embedding feature selection with classifier construction, have the advantages of (1) wrapper
    models - they include the interaction with the classification model and (2) filter models - they are far less
    computationally intensive than wrapper methods.

    There are three types of embedded methods. The first are pruning methods that first utilize all features to train
    a model and then attempt to eliminate some features by setting the corresponding coefficients to 0, while maintaining
    model performance such as recursive feature elimination using support vector machine (SVM). The second are models
    with a built-in mechanism for feature selection such as ID3 and C4.5. The third are regularization models with
    objective functions that minimize fitting errors and in the meantime force the coefficients to be small or to be
    exactly zero. Features with coefficients that are close to 0 are then eliminated.
    """
    def __init__(self):
        """Initialize an instance of Embedded."""
        self.x = None
        self.y = None

    def model(self, x: DataFrame, y: DataFrame, model_type: ModelType = ModelType.RF, n_estimator: int = 100) -> List[str]:
        """
        Perform feature selection using the specified model type.

        Args:
            x: The input data.
            y: The target data.
            model_type (ModelType): The type of the model to use for feature selection. Default is ModelType.RF.
            n_estimator (int): The number of trees in the forest for the RandomForestClassifier. Default is 100.

        Returns:
            A list of selected features.
        """
        self.x = x
        self.y = y
        model = self._create_model(model_type, n_estimator)
        sel_ = SelectFromModel(model)
        sel_.fit(self.x, self.y)
        selected_feat = self.x.columns[(sel_.get_support())]
        return selected_feat.tolist()

    @staticmethod
    def _create_model(model_type: ModelType, n_estimator: int) -> ClassifierMixin:
        if model_type == ModelType.RF:
            return RandomForestClassifier(n_estimators=n_estimator)
        elif model_type == ModelType.GBT:
            return GradientBoostingClassifier()
        elif model_type == ModelType.DT:
            return DecisionTreeClassifier()
        else:
            raise ValueError(f"Invalid model type. Supported types are {list(ModelType)}.")


if __name__ == "__main__":
    data = read_csv("../csv/ELSAwave6and8_friedcriterion.csv", num_rows=100)
    X_train, y_train = split_train_test(data, label_target="frail_cat6")
    update(X_train, "frail_cat8")

    # Create an instance of Embedded class
    embedded_model = Embedded()
    selected_features = embedded_model.model(X_train, y_train, ModelType.RF)
    print(selected_features)
