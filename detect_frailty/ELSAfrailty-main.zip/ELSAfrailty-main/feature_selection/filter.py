from typing import List

from utils import read_csv, split_train_test, constant_feature, remove_features, quasi_feature, duplicate_feature, \
    correlation, fishier_score, update


class Filter:
    def __init__(self, data_path: str, _correlation: float = 0.8):
        """Initialize an instance of Filter.

        Args:
            data_path: str to the path
        """
        self.data = read_csv(data_path, num_rows=100)
        self.correlation = _correlation
        self.x = None
        self.y = None

    def preprocess(self):
        """Preprocess the data."""
        self.x, self.y = split_train_test(self.data, label_target="frail_cat6")
        update(self.x, "frail_cat8")

    @staticmethod
    def feature_remove(x, features_list: List):
        """Remove specified features from the dataset.

        Args:
            x: The input data.
            features_list (List[str]): List of feature names to be removed.
        """
        remove_features(x, features_list)

    @staticmethod
    def feature_constant(x):
        """Identify and return constant features."""
        return constant_feature(x)

    @staticmethod
    def feature_quasi(x):
        """Identify and return quasi constant features."""
        return quasi_feature(x)

    @staticmethod
    def feature_duplicate(x):
        """Identify and return duplicate features."""
        return duplicate_feature(x)

    def feature_correlated(self, x):
        """Identify and return correlated features."""
        return correlation(x, self.correlation)

    def run(self):
        self.preprocess()
        self.feature_remove(self.x, self.feature_constant(self.x))
        self.feature_remove(self.x, self.feature_quasi(self.x))
        self.feature_remove(self.x, self.feature_duplicate(self.x))
        self.feature_remove(self.x, self.feature_correlated(self.x))


if __name__ == '__main__':
    filters = Filter(data_path="../csv/ELSAwave6and8_friedcriterion.csv")
    filters.run()

    fishier_score(filters.x, filters.y)
