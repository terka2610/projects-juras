from typing import List, Dict, Iterable, Tuple, Set

import numpy as np
import pandas as pd

from feature_selection.utils import mmatch


class RoughSet:
    def __init__(self, data: List, decision: List):
        self.universe_set = data
        self.decision_set = decision

    @staticmethod
    def indistinguishable(attribute_list: List, d):
        """
        Perform indiscernibility relation on the given data.

        Args:
            attribute_list (list): List of attributes to consider for indiscernibility.
            d (pd.DataFrame): DataFrame containing the data.

        Returns:
            list: List of lists representing the indiscernibility relation.
        """
        ultimate_list = []
        # Copy the DataFrame to avoid modifying original data
        r_data = d.copy()
        for i in range(len(d)):
            df = d.iloc[[i]]
            tt_list, r_data = mmatch(attribute_list, df, i, r_data)
            ultimate_list.append(tt_list)

        return ultimate_list

    @staticmethod
    def equivalence_partition(iterable: Iterable, index: List[int]) -> Tuple[List[Set[int]], Dict[int, Set[int]]]:
        """
        Partition the iterable into equivalence classes based on the given index.

        Args:
            iterable: Iterable containing objects.
            index: List of indices to compare for equivalence.

        Returns:
            Tuple containing:
                - List of equivalence classes.
                - Dictionary mapping object to its equivalence class.
        """
        classes = []  # List to store equivalence classes
        d_classes = {}  # Dictionary to map object to its equivalence class
        for o in iterable:  # Iterate over each object
            found = False
            for c in classes:
                indice_ele = next(iter(c))
                element = [iterable[indice_ele][ind] == o[ind] for ind in index]
                if all(element):
                    c.add(o[0])
                    d_classes[o[0]] = c
                    found = True
                    break
            if not found:
                classes.append({o[0]})
                d_classes[o[0]] = classes[-1]
        return classes, d_classes

    def lower_approximation(self, subset: Set[int]) -> Set[int]:
        """Compute the lower approximation set and positive region for a given subset.

        Args:
            subset: Set of indices representing the subset.

        Returns:
            Set of indices representing the lower approximation set.
        """
        _, ind_B_dict = self.equivalence_partition(self.universe_set, subset)
        _, ind_d_dict = self.equivalence_partition(self.universe_set, self.decision_set)
        lower_appr_set = set()
        for idx, _ in enumerate(self.universe_set):
            if ind_B_dict[idx].issubset(ind_d_dict[idx]):
                lower_appr_set.add(idx)
        return lower_appr_set

    def gamma(self, attribute_set: Set[int]) -> float:
        """
        Compute the gamma value for a given subset.

        Args:
            attribute_set: Set of indices representing the subset.

        Returns:
            Gamma value for the subset.
        """
        lower_appr_size = len(self.lower_approximation(attribute_set))
        universe_size = len(self.universe_set)
        return float(lower_appr_size) / float(universe_size)

    def qreduct(self, attribute_set: Set[int]) -> Set[int]:
        """
        Compute the reduct set for a given set C using the QuickReduct algorithm.

        Args:
            attribute_set: Set of attributes.

        Returns:
            Set representing the reduct.
        """
        reduct = set()
        while True:
            best_reduct = reduct
            for attribute in attribute_set - reduct:
                if self.gamma(reduct.union({attribute})) > self.gamma(best_reduct):
                    best_reduct = reduct.union({attribute})

            reduct = best_reduct
            if self.gamma(reduct) == self.gamma(attribute_set):
                break

        return reduct

    @staticmethod
    def inner_upper_value(result_table, i_list):
        """
        Find the inner upper value from the result table based on the given index list.

        Args:
            result_table (pd.DataFrame): DataFrame containing the result table.
            i_list (list): List of index lists.

        Returns:
            list: List of inner upper values.
        """
        upper_list = []
        for i in range(len(i_list)):
            flag = 0
            for j in range(len(i_list[i])):
                rr = result_table[result_table['id'] == i_list[i][j]]
                if len(rr) > 0:
                    flag = 1
                    break
                else:
                    flag = 0
            if flag == 1:
                for tv in i_list[i]:
                    upper_list.append(tv)
        return upper_list

    def upper_value(self, r_data: pd.DataFrame, o_values: List[str], i_list: List[List[int]],
                    output_attribute_name: str) -> \
            Dict[str, List[int]]:
        """
        Find the upper value for each value in the list of output values based on the result data and index list.

        Args:
            r_data: DataFrame containing the result data.
            o_values: List of output values.
            i_list: List of index lists.
            output_attribute_name: Name of the output attribute in the DataFrame.

        Returns:
            Dictionary containing the upper values for each output value.
        """
        # Initialize an empty dictionary to store upper values for each output value
        upper_list = {}

        # Iterate over each output value
        for v in o_values:
            ul = []  # Initialize an empty list to store upper values
            # Filter result data based on the output value
            tl = r_data[r_data[output_attribute_name] == v]
            # Find inner upper value using the filtered data and index list
            ul = self.inner_upper_value(tl, i_list)
            # Store the upper values for the current output value in the dictionary
            upper_list[v] = ul

        return upper_list

    def lower_value(self, r_data: pd.DataFrame, o_values: List[str], ind_list: List[List[int]],
                    output_attribute_name: str) -> \
            Dict[str, List[int]]:
        """
        Find the lower value for each value in the list of output values based on the result data and index list.

        Args:
            r_data: DataFrame containing the result data.
            o_values: List of output values.
            ind_list: List of index lists.
            output_attribute_name: Name of the output attribute in the DataFrame.

        Returns:
            Dictionary containing the lower values for each output value.
        """
        lower_list = {}
        for v in o_values:
            ul = []  # Initialize an empty list to store lower values
            # Filter result data based on the output value
            tl = r_data[r_data[output_attribute_name] == v]
            # Find inner lower value using the filtered data and index list
            ul = self.inner_lower_value(tl, ind_list)
            # Store the lower values for the current output value in the dictionary
            lower_list[v] = ul

        return lower_list

    @staticmethod
    def inner_lower_value(result_table: pd.DataFrame, ind_list: List[List[int]]) -> List[int]:
        """
        Find the inner lower value from the result table based on the given index list.

        Args:
            result_table: DataFrame containing the result table.
            ind_list: List of index lists.

        Returns:
            List of inner lower values.
        """
        lower_list = []
        for i in range(len(ind_list)):
            flag = 0
            for j in range(len(ind_list[i])):
                rr = result_table[result_table['id'] == ind_list[i][j]]
                if len(rr) > 0:
                    flag = 1
                else:
                    flag = 0
                    break
            if flag == 1:
                for tv in ind_list[i]:
                    lower_list.append(tv)
        return lower_list

    @staticmethod
    def positive_region(lower_appr1, lower_appr2):
        lower_approx_pos_set = set(lower_appr1)
        lower_approx_neg_set = set(lower_appr2)
        positive_region = lower_approx_pos_set.union(lower_approx_neg_set)
        return positive_region


class RoughSetsReducer:

    @staticmethod
    def __size(x):
        return (1, x.shape[0]) if x.ndim == 1 else x.shape

    '''
    Calculates indistinguishable relation
    '''

    def indisc(self, a, x):

        def codea(a, x, b):
            yy = 0
            for i in range(0, a):
                yy += x[i] * b ** (a - (i + 1))
            return yy

        p, q = self.__size(x)
        ap, aq = self.__size(a)
        z = [e for e in range(1, q + 1)]
        tt = np.setdiff1d(z, a)
        tt_ind = np.setdiff1d(z, tt) - 1
        if x.ndim == 1:
            x = x[tt_ind]
        else:
            x = x[:, tt_ind]
        y = x
        v = [codea(aq, y, 10) for i in range(0, p)] if y.ndim == 1 \
            else [codea(aq, y[i, :], 10) for i in range(0, p)]
        y = np.transpose(v)
        if y.shape[0] == 1 and len(y.shape) == 1:
            I, yy = [1], [y]
            y = np.hstack((y, I))
            b, k, l = [y], [1], [1]
        else:
            ax = 1 if y.ndim > 1 else 0
            yy = np.sort(y, axis=ax)
            I = y.argsort(axis=ax)
            y = np.hstack((yy, I))
            b, k, l = np.unique(yy, return_index=True, return_inverse=True)
        y = np.hstack((l, I))
        m = np.max(l)
        aa = np.zeros((m + 1, p), dtype=int)
        for ii in range(0, m + 1):
            for j in range(0, p):
                if l[j] == ii:
                    aa[ii, j] = I[j] + 1
        return aa

    '''
    Calculates lower approximation set of y
    '''

    def rslower(self, y, a, T):
        z = self.indisc(a, T)
        w = []
        p, q = self.__size(z)
        for u in range(0, p):
            zz = np.setdiff1d(z[u, :], 0)
            if np.in1d(zz, y).all():
                w = np.hstack((w, zz))
        return w.astype(dtype=int)

    '''
    Calculates upper approximation set of y
    '''

    def rsupper(self, y, a, T):
        z = self.indisc(a, T)
        w = []
        p, q = self.__size(z)
        for u in range(0, p):
            zz = np.setdiff1d(z[u, :], 0)
            zzz = np.intersect1d(zz, y)
            if len(zzz) > 0:
                w = np.hstack((w, zz))
        return w.astype(dtype=int)

    def __pospq(self, p, q):
        pm, pn = self.__size(p)
        qm, qn = self.__size(q)
        num = 0
        pp, qq = [[]] * pm, [[]] * qm
        for i in range(0, pm):
            pp[i] = np.unique(p[i, :])
        for j in range(0, qm):
            qq[j] = np.unique(q[j, :])
        b = []
        for i in range(0, qm):
            for j in range(0, pm):
                if np.in1d(pp[j], qq[i]).all():
                    num += 1
                    b = np.hstack((b, pp[j]))
        bb = np.unique(b)
        if bb.size == 0:
            dd = 1
        else:
            _, dd = self.__size(bb)
        y = float(dd - 1) / pn if 0 in bb else float(dd) / pn
        b = np.setdiff1d(bb, 0)
        return y, b

    '''
    Extract core set from C to D
    '''

    def core(self, C, D):
        x = np.hstack((C, D))
        c = np.array(range(1, C.shape[1] + 1))
        d = np.array([C.shape[1] + 1])
        cp, cq = self.__size(c)
        q = self.indisc(d, x)
        pp = self.indisc(c, x)
        b, w = self.__pospq(pp, q)
        a, k, kk, p = ([[]] * cq for i in range(4))
        y = []
        for u in range(0, cq):
            ind = u + 1
            a[u] = np.setdiff1d(c, ind)
            p[u] = self.indisc(a[u], x)
            k[u], kk[u] = self.__pospq(p[u], q)
            if k[u] != b:
                y = np.hstack((y, ind))
        return np.array(y)

    def __sgf(self, a, r, d, x):
        pr = self.indisc(r, x)
        q = self.indisc(d, x)
        b = np.hstack((r, a))
        pb = self.indisc(b, x)
        p1, _ = self.__pospq(pb, q)
        p2, _ = self.__pospq(pr, q)
        return p1 - p2

    '''
    Return the set of irreducible attributes
    '''

    def reduce(self, C, D):

        def redu2(i, re, c, d, x):
            yre = re
            re1, re2 = self.__size(re)
            q = self.indisc(d, x)
            p = self.indisc(c, x)
            pos_cd, _ = self.__pospq(p, q)
            y, j = None, None
            for qi in range(i, re2):
                re = np.setdiff1d(re, re[qi])
                red = self.indisc(re, x)
                pos_red, _ = self.__pospq(red, q)
                if np.array_equal(pos_cd, pos_red):
                    y = re
                    j = i
                    break
                else:
                    y = yre
                    j = i + 1
                    break
            return y, j

        x = np.hstack((C, D))
        c = np.array(range(1, C.shape[1] + 1))
        d = np.array([C.shape[1] + 1])
        y = self.core(C, D)
        q = self.indisc(d, x)
        p = self.indisc(c, x)
        pos_cd, _ = self.__pospq(p, q)
        re = y
        red = self.indisc(y, x)
        pos_red, _ = self.__pospq(red, q)
        while pos_cd != pos_red:
            cc = np.setdiff1d(c, re)
            c1, c2 = self.__size(cc)
            yy = [0] * c2
            for i in range(0, c2):
                yy[i] = self.__sgf(cc[i], re, d, x)
            cd = np.setdiff1d(c, y)
            d1, d2 = self.__size(cd)
            for i in range(d2, c2, -1):
                yy[i] = []
            ii = np.argsort(yy)
            for v1 in range(c2 - 1, -1, -1):
                v2 = ii[v1]
                re = np.hstack((re, cc[v2]))
                red = self.indisc(re, x)
                pos_red, _ = self.__pospq(red, q)
        re1, re2 = self.__size(re)
        core = y
        for qi in range(re2 - 1, -1, -1):
            if re[qi] in core:
                y = re
                break
            re = np.setdiff1d(re, re[qi])
            red = self.indisc(re, x)
            pos_red, _ = self.__pospq(red, q)
            if np.array_equal(pos_cd, pos_red):
                y = re
        y1, y2 = self.__size(y)
        j = 0
        for i in range(0, y2):
            y, j = redu2(j, y, c, d, x)
        return y
