import collections
from typing import List, Any, Dict
import pandas as pd
from pandas import DataFrame
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import VarianceThreshold, mutual_info_classif, chi2
from sklearn.metrics import roc_auc_score

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import warnings

from utils.utils import read_csv

warnings.simplefilter(action='ignore', category=FutureWarning)

category_dict = {
    "non-frail": 0,
    "pre-frail": 1,
    "frail": 2
}


def split_train_test(data: DataFrame,
                     label_target: str,
                     data_category: str = "TRAIN",
                     test_size: float = 0.3):
    X_train, X_test, y_train, y_test = train_test_split(
        data.drop(labels=[label_target], axis=1),
        data[label_target],
        test_size=test_size,
        random_state=0)
    return (X_train, y_train) if data_category == "TRAIN" else (X_test, y_test)


def describe(data: DataFrame, data_type: str = None):
    if data_type is None:
        return data.describe()
    return data.describe(include=[data_type])


def variance_threshold(data: DataFrame,
                       threshold: float = 0) -> VarianceThreshold:
    # fit finds the features with low variance
    sel = VarianceThreshold(threshold=threshold)
    sel.fit(data)
    return sel


def constant_feature(data: DataFrame) -> List:
    return [x for x in data.columns if data[x].std() == 0]


def check_null(data: DataFrame) -> List:
    return [col for col in data.columns if data[col].isnull().sum() > 0]


def remove_features_from_dataframe(data: DataFrame,
                                   labels: List,
                                   row_column: int = 1) -> None:
    data.drop(labels=labels, axis=row_column, inplace=True)


def remove_features(data: Any,
                    labels: List,
                    row_column: int = 1) -> None:
    if labels:
        if isinstance(data, DataFrame):
            remove_features_from_dataframe(data, labels=labels, row_column=row_column)
        elif isinstance(data, List):
            for item in data:
                remove_features_from_dataframe(item, labels=labels, row_column=row_column)


def quasi_feature(data: DataFrame, thresholds: float = 0.998):
    quasi_constant_feat = []
    for feature in data.columns:

        # find the predominant value
        predominant = (data[feature].value_counts() / float(
            len(data))).sort_values(ascending=False).values[0]

        # evaluate predominant feature
        if predominant > thresholds:
            quasi_constant_feat.append(feature)
    return quasi_constant_feat


def duplicate_feature(data: DataFrame):
    """check for duplicated features in the training set

    Args:
        data: DataFrame includes all the target data

    Returns:
        A list contains all the duplicate features
    """
    duplicated_feat = []
    for i in range(0, len(data.columns)):
        if i % 10 == 0:
            print(i)
        col_1 = data.columns[i]

        for col_2 in data.columns[i + 1:]:
            if data[col_1].equals(data[col_2]):
                duplicated_feat.append(col_2)
    return duplicated_feat


def correlation(data: DataFrame,
                threshold: float) -> List:
    """find and remove correlated features

    Args:
        data:
        threshold:

    Returns:

    """
    col_corr = set()  # Set of all the names of correlated columns
    corr_matrix = data.corr()
    for i in range(len(corr_matrix.columns)):
        for j in range(i):
            if abs(corr_matrix.iloc[i, j]) > threshold:
                col_name = corr_matrix.columns[i]  # getting the name of column
                col_corr.add(col_name)
    return list(col_corr)


def update_dataframe(data: DataFrame, column_name: str, dict_rel: dict):
    updateSer = data[column_name].map(dict_rel)
    data[column_name] = updateSer


def update(x: DataFrame, labels: Any, dict_map: Dict = None) -> None:
    if dict_map is None:
        dict_map = category_dict
    if isinstance(labels, str):
        update_dataframe(x, labels, dict_map)
    if isinstance(labels, List):
        for item in labels:
            update_dataframe(x, item, dict_map)


def mutual_information(x: DataFrame, y: DataFrame, plot: bool = True):
    # update_dataframe(x, "frail_cat8", category_dict)
    # update_dataframe(x, "frail_cat8", category_dict)
    mi = mutual_info_classif(x, y)
    mi = pd.Series(mi)
    mi.index = x.columns
    mi.sort_values(ascending=False)
    if plot:
        mi.sort_values(ascending=False).plot.bar()
        plt.show()
    print(">> Finished.")


def fishier_score(x: DataFrame, y: DataFrame):
    # update(x, "frail_cat8")
    f_score = chi2(x, y)
    p_values = pd.Series(f_score[1])
    p_values.index = x.columns
    p_values.sort_values(ascending=False).plot.bar()
    plt.show()


def run_random_forests(X_train, X_test, Y_train, Y_test, num_tree: int = 100, random_rate: int = 40, max_depth: int = 4):
    rf = RandomForestClassifier(n_estimators=num_tree, random_state=random_rate, max_depth=max_depth)
    rf.fit(X_train, Y_train)
    print('Train set')
    pred = rf.predict_proba(X_train)
    print('Random Forests roc-auc: {}'.format(roc_auc_score(Y_train, pred[:, 1])))
    print('Test set')
    pred = rf.predict_proba(X_test)
    print('Random Forests roc-auc: {}'.format(roc_auc_score(Y_test, pred[:, 1])))


def mmatch(attribute_list, df, index, reference_data):
    """
    Match records in the reference data based on the specified attributes.

    Args:
        attribute_list (list): List of attributes to match.
        df (DataFrame): DataFrame containing the data to be matched against.
        index (int): Index of the row in the DataFrame to be used for matching.
        reference_data (DataFrame): Reference DataFrame containing the data to be matched.

    Returns:
        tuple: A tuple containing two elements:
            - List of matched IDs
            - Updated reference data after removing matched records
    """
    unique_matched_ids = []
    matched_ids = []
    for attribute in attribute_list:
        # Filter reference data based on the attribute value from the dataframe
        filtered_data = reference_data[reference_data[attribute] == df[attribute][index]]
        # Append IDs from filtered data to the matched IDs list
        for idd in filtered_data.id:
            matched_ids.append(idd)

    # Count occurrences of each ID in the matched IDs list
    counter = collections.Counter(matched_ids)
    for key, value in counter.items():
        if value == len(attribute_list):
            unique_matched_ids.append(key)
            # Remove matched records from the reference data
            reference_data = reference_data[reference_data['id'] != key]

    return unique_matched_ids, reference_data


if __name__ == '__main__':
    path = "../csv/ELSAwave6and8_friedcriterion.csv"
    sample = read_csv(path)
    # print(sample.describe())
    x_train, y_train = split_train_test(sample, label_target="frail_cat6")
    # print(duplicate_feature(x_train))
    print(type(x_train))
    # mutual_information(x_train, y_train)
    fishier_score(x_train, y_train)
