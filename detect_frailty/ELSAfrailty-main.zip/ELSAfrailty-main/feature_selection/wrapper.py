from typing import List

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from mlxtend.feature_selection import ExhaustiveFeatureSelector as EFS

from utils import read_csv, split_train_test


class Wrapper:
    """
    Greedy search algorithms

    utilise a specific classifier to select the optimal set of features

    Sequential feature selection algorithms add or remove one feature at the time based on the classifier performance
    until a feature subset of the desired size k is reached, or any other desired criteria is met. They are used to
    reduce an initial d-dimensional feature space to a k-dimensional feature subspace where k < d.

    Exhaustive feature selection algorithms select the best subset of features over all the possible feature subsets
    by optimizing a specified performance metric for a certain machine learning algorithm.
    """

    def __init__(self,
                 data_path: str,
                 num_trees: int = 10):
        """
        Initialize the Wrapper object.

        Args:
            data_path (str): Path to the CSV file containing the dataset.
            num_trees (int): Number of trees for the Random Forest classifier (default is 10).
        """
        self.random_forest = RandomForestClassifier(n_estimators=num_trees, n_jobs=4, random_state=0)
        self.data = read_csv(data_path, num_rows=100)
        self.x, self.y = split_train_test(self.data, label_target="frail_cat6")

    def _create_sfs(self,
                    num_features: int,
                    forward: bool = True,
                    scoring: str = "roc_auc"):
        """
        Create a new SequentialFeatureSelector object.

        Args:
            num_features (int): The number of features to select.
            forward (bool): Whether to perform forward selection (default is True).
            scoring (str): Scoring metric for feature selection (default is "roc_auc").

        Returns:
            SFS: A new SequentialFeatureSelector object.
        """
        return SFS(self.random_forest, k_features=num_features, forward=forward, floating=False, verbose=2,
                  scoring=scoring, cv=3)

    def step_forward(self,
                     x: np.array = None,
                     y: List = None,
                     num_features: int = 1) -> List:
        """
        Perform step forward feature selection.

        Args:
            x (np.array): The training data (default is None, will use self.x).
            y (List): The labels for the training data (default is None, will use self.y).
            num_features (int): The number of features to select (default is 1).

        Returns:
            List: A list containing the selected features' names.
        """
        sfs = self._create_sfs(num_features)
        x = self.x if x is None else x
        y = self.y if y is None else y
        sfs = sfs.fit(x, y)
        selected_feat = x.columns[list(sfs.k_feature_idx_)]
        return selected_feat

    def step_backward(self,
                     x: np.array = None,
                     y: List = None,
                     num_features: int = 1) -> List:
        """
        Perform step backwards feature selection.

        Args:
            x (np.array): The training data (default is None, will use self.x).
            y (List): The labels for the training data (default is None, will use self.y).
            num_features (int): The number of features to select (default is 1).

        Returns:
            List: A list containing the remaining features' names.
        """
        sfs = self._create_sfs(num_features, forward=False)
        x = self.x if x is None else x
        y = self.y if y is None else y
        sfs = sfs.fit(x, y)
        selected_feat = x.columns[list(sfs.k_feature_idx_)]
        return selected_feat

    def exhaustive(self,
                   x: np.array = None,
                   y: List = None,
                   min_features: int = 1,
                   max_features: int = 4,
                   scoring: str = "roc_auc") -> List:
        """
        Perform exhaustive feature selection.

        Args:
            x (np.array): The training data (default is None, will use self.x).
            y (List): The labels for the training data (default is None, will use self.y).
            min_features (int): Minimum number of features to select (default is 1).
            max_features (int): Maximum number of features to select (default is 4).
            scoring (str): Scoring metric for feature selection (default is "roc_auc").

        Returns:
            List: A list containing the best subset of features.
        """
        efs = EFS(RandomForestClassifier(n_jobs=4, random_state=0),
                  min_features=min_features,
                  max_features=max_features,
                  scoring=scoring,
                  print_progress=True,
                  cv=2)
        x = self.x if x is None else x
        y = self.y if y is None else y
        efs1 = efs.fit(x, y)
        selected_feat= x.columns[list(efs1.best_idx_)]
        return selected_feat
