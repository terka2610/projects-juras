# ELSA Wave 8
# 5050_harmonized_elsa_g3_2002-2019

# Packages
import os
import sys

import pandas as pd
import numpy as np
import warnings

from pandas import DataFrame

warnings.filterwarnings('ignore')
pd.set_option('display.max_rows', None)
current_path = os.path.dirname(__file__) + '/'

file_path = "../tab/h_elsa_g3.tab"
save_path = "../csv/ELSAwave6and8_friedcriterion.csv"

def load_data(path: str) -> DataFrame:
    """Attempting to read the .tab file

    Args:
        path: The path to the file

    Returns:
        Dataframe contains all the data
    """
    try:
        # Attempt to read the .tab file
        frame = pd.read_csv(current_path + path, sep='\t')
        return frame
    except FileNotFoundError as e:
        raise FileNotFoundError(f"File not found at {path}") from e
    except pd.errors.EmptyDataError as e:
        raise pd.errors.EmptyDataError(f"Empty file at {path}") from e
    except pd.errors.ParserError as e:
        raise pd.errors.ParserError(f"Parsing error in file {path}: {e}") from e
    except Exception as e:
        raise Exception(f"An unexpected error occurred while reading file {path}: {e}") from e


def categorize_frailty(score: int) -> str:
    """Categorize frailty based on the score.

    Args:
        score (int): The frailty score.

    Returns:
        str: The corresponding frailty category.
    """
    frailty_mapping = {
        0: 'non-frail',
        1: 'pre-frail',
        2: 'pre-frail'
    }

    return frailty_mapping.get(score, 'frail')


def calculate_and_categorize(num_year: str) -> DataFrame:
    """Calculate frailty scores and categorize them.

    Args:
        num_year (str): Wave number.

    Returns:
        DataFrame: DataFrame containing the calculated scores and categories.
    """
    # Check the type of the input variable
    if not isinstance(num_year, (int, str)):
        raise TypeError("The type of the input is not int or str, please check!")

    num_year = str(num_year)
    print('Calculate for wave ' + num_year)

    # Columns names
    grip_cols = ['r' + num_year + 'lgrip', 'r' + num_year + 'rgrip']
    wspeed_col = 'r' + num_year + 'wspeed'
    bmi_col = 'r' + num_year + 'mbmi'
    vgactx_col = 'r' + num_year + 'vgactx_e'
    mdactx_col = 'r' + num_year + 'mdactx_e'
    effort_col = 'r' + num_year + 'effort'
    going_col = 'r' + num_year + 'going'

    # Grip Strength
    frailty_df['maxgrip' + num_year] = frailty_df[grip_cols].mean(axis=1)
    frailty_df['weakness' + num_year] = (frailty_df.groupby('ragender')['maxgrip' + num_year]
                                         .transform(
        lambda x: pd.qcut(x, q=5, labels=False, duplicates='drop')) == 0).astype(int)

    # Walking Speed
    frailty_df['walkingspeed' + num_year] = (frailty_df.groupby('ragender')[wspeed_col]
                                             .transform(
        lambda x: pd.qcut(x, q=5, labels=False, duplicates='drop')) == 0).astype(int)

    # Weight Loss
    frailty_df['weightloss' + num_year] = (frailty_df[bmi_col] < 18.5).astype(int)

    # Low PA
    frailty_df['lowpa' + num_year] = ((frailty_df[vgactx_col] == 5) & (frailty_df[mdactx_col] == 5)).astype(int)

    # Exhaustion
    frailty_df['exhaustion' + num_year] = ((frailty_df[effort_col] == 1) | (frailty_df[going_col] == 1)).astype(int)

    # Calculate frailty sum and categorize
    frailty_df['frail_sum' + num_year] = frailty_df[['weakness' + num_year, 'walkingspeed' + num_year,
                                                     'weightloss' + num_year, 'lowpa' + num_year,
                                                     'exhaustion' + num_year]].sum(axis=1)
    frailty_df['frail_cat' + num_year] = frailty_df['frail_sum' + num_year].apply(categorize_frailty)

    # Select relevant columns
    selected_columns = ['idauniq', 'weakness' + num_year, 'walkingspeed' + num_year, 'weightloss' + num_year,
                        'lowpa' + num_year, 'exhaustion' + num_year, 'frail_sum' + num_year, 'frail_cat' + num_year]

    return frailty_df[selected_columns].copy()


if __name__ == '__main__':
    ############################################################################################
    # DETERMINE IF PEOPLE ARE RESPONDING IN WAVE 6
    # r6iwstat/r8iwstat
    # 1: resp, alive
    # 4: no response, alive
    # 5: died between the last interview and the current one
    # 6: died in the previous wave
    # 9: no response, don't know if alive or died

    # At wave 8, there are no values coded as 5 or 6, so eep participants who are alive and
    # responded (=1) at wave 6 and 8
    ############################################################################################
    # Load Data
    df = load_data(file_path)
    df_responded = df[(df['r6iwstat'] == 1) & (df['r8iwstat'] == 1)]

    # EXCLUDE ANYONE YOUNGER THAN 50 AT WAVE 6
    df_responded['r6agey'] = pd.to_numeric(df_responded['r6agey'], errors='coerce')
    df_responded = df_responded[df_responded['r6agey'] > 50]

    # NOW REDUCE THE DF COS THE ORIGINAL IS MASSIVE AF.
    df_reduced = df_responded.loc[:, ['idauniq', 'r6agey', 'ragender',
                                      'r6mbmi', 'r8mbmi',
                                      'r6lgrip', 'r6rgrip', 'r8lgrip', 'r8rgrip',
                                      'r6wspeed', 'r8wspeed',
                                      'r6vgactx_e', 'r6mdactx_e', 'r8vgactx_e', 'r8mdactx_e',
                                      'r6effort', 'r6going', 'r8effort', 'r8going']].copy()

    # List of columns to filter and adjust
    columns_to_adjust = ['r6effort', 'r8effort', 'r6going', 'r8going']

    # replace " " with NaN
    df_reduced.replace(" ", np.nan, inplace=True)

    # Drop NaN Values
    df_reduced.dropna(inplace=True)
    # df_reduced.shape

    # Counting NaN values in all columns
    nan_count = df_reduced.isna().sum()
    # print(nan_count)

    # Change columns to numeric
    object_cols = df_reduced.select_dtypes(include=['object']).columns

    for col in object_cols:
        try:
            df_reduced[col] = pd.to_numeric(df_reduced[col])
        except ValueError:
            print(f"Unable to convert column {col} to numeric.")

    # NOW CALCULATE THE FRIED CATEGORIZATION FOR EACH WAVE
    frailty_df = df_reduced

    fried_criteria_wave6 = calculate_and_categorize('6')
    fried_criteria_wave8 = calculate_and_categorize('8')

    print('>> Merge the data')
    # Merge that data
    merged_df = pd.merge(fried_criteria_wave6, fried_criteria_wave8, on='idauniq', how='inner')

    # Compare counts
    counts_table = pd.DataFrame({
        'frail_cat6': merged_df['frail_cat6'].value_counts(),
        'frail_cat8': merged_df['frail_cat8'].value_counts()
    })

    print("Counts for 'frail_cat6' and 'frail_cat8':")
    print(counts_table)

    # Specify the full file path where you want to save the DataFrame
    merged_df.to_csv(save_path, index=False)

    sys.exit()
