from typing import Union, List

import pandas as pd
from sklearn.linear_model import LinearRegression


def drop_cols(df: pd.DataFrame, col_name: Union[str, List[str]]):
    """
    Drop column(s) from the DataFrame.

    Args:
        df (pd.DataFrame): The DataFrame from which columns are to be dropped.
        col_name (Union[str, List[str]]): Name of the column or list of column names to be dropped.

    Returns:
        None. The DataFrame is modified inplace.
    """
    if isinstance(col_name, str):
        col_name = [col_name]
    df.drop(columns=col_name, inplace=True)


def proportion_null(df: pd.DataFrame, target_attribute: str) -> Union[float, None]:
    """
    Calculate the proportion of null values for a specific attribute in a DataFrame.

    Parameters:
        df (pd.DataFrame): The DataFrame to analyze.
        target_attribute (str): The target attribute to check for null values.

    Returns:
        float or None: The proportion of null values for the target attribute, or None if the attribute is not found.
    """

    # Check if the input DataFrame is valid
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input 'df' must be a pandas DataFrame")

    # Check if the target_attribute is a string
    if not isinstance(target_attribute, str):
        raise ValueError("Input 'target_attribute' must be a string")

    # Check if the target_attribute exists in the DataFrame
    if target_attribute not in df.columns:
        print(f"Warning: '{target_attribute}' does not exist in the DataFrame.")
        return None

    # Calculate the proportion of null values for the target attribute
    null_proportion = (df[target_attribute].isnull().sum() / df.shape[0]) * 100
    return null_proportion


def fill_missing_values(df: pd.DataFrame, method: str):
    """
    Fill missing values in a DataFrame based on specified method.

    Parameters:
        df (pd.DataFrame): The DataFrame to fill missing values.
        method (str): The method to fill missing values, should be one of 'mean', 'median', or 'mode'.

    Returns:
        pd.DataFrame: DataFrame with missing values filled according to the specified method.
    """
    if method == 'mean':
        return df.fillna(df.mean())
    elif method == 'median':
        return df.fillna(df.median())
    elif method == 'mode':
        return df.fillna(df.mode().iloc[0])  # Use iloc[0] to get the first mode
    else:
        raise ValueError("Invalid method. Method should be one of 'mean', 'median', or 'mode'.")


def fill_missing_values_for_columns(df: pd.DataFrame, columns: list, method: str):
    """
    Fill missing values in specified columns of a DataFrame based on specified method.

    Parameters:
        df (pd.DataFrame): The DataFrame to fill missing values.
        columns (list): A list of column names to fill missing values.
        method (str): The method to fill missing values, should be one of 'mean', 'median', or 'mode'.

    Returns:
        pd.DataFrame: DataFrame with missing values in specified columns filled according to the specified method.
    """

    # Make a copy of the DataFrame to avoid modifying the original
    filled_df = df.copy()

    # Fill missing values for specified columns using the fill_missing_values function
    for column in columns:
        if column not in filled_df.columns:
            print(f"Warning: Column '{column}' does not exist in the DataFrame.")
            continue
        filled_df[column] = fill_missing_values(filled_df[[column]], method)

    return filled_df


def interpolate_missing_values(df: pd.DataFrame, columns: list, method: str):
    """
    Interpolate missing values in specified columns of a DataFrame based on specified method.

    Parameters:
        df (pd.DataFrame): The DataFrame to interpolate missing values.
        columns (list): A list of column names to interpolate missing values.
        method (str): The method of interpolation, should be one of 'linear', 'quadratic', 'cubic', 'spline', etc.

    Returns:
        pd.DataFrame: DataFrame with missing values in specified columns interpolated according to the specified method.
    """

    # Make a copy of the DataFrame to avoid modifying the original
    interpolated_df = df.copy()

    # Interpolate missing values for specified columns
    for column in columns:
        if column not in interpolated_df.columns:
            print(f"Warning: Column '{column}' does not exist in the DataFrame.")
            continue
        interpolated_df[column] = interpolated_df[column].interpolate(method=method)

    return interpolated_df


def multivariate_interpolation(df: pd.DataFrame, columns: list, target_column: str):
    """
    Fill missing values in specified columns of a DataFrame using multivariate interpolation with Linear Regression.

    Parameters:
        df (pd.DataFrame): The DataFrame containing missing values to interpolate.
        columns (list): A list of column names to perform multivariate interpolation.
        target_column (str): The target column with missing values to interpolate.

    Returns:
        pd.DataFrame: DataFrame with missing values in specified columns interpolated using Linear Regression.
    """

    # Make a copy of the DataFrame to avoid modifying the original
    interpolated_df = df.copy()

    # Filter rows with missing values in the target column
    missing_rows = interpolated_df[target_column].isnull()

    # Prepare training data
    X_train = interpolated_df[~missing_rows & ~interpolated_df[columns].isnull().any(axis=1)][columns]
    y_train = interpolated_df[~missing_rows & ~interpolated_df[target_column].isnull()][target_column]

    # Initialize and fit the linear regression model
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Predict missing values
    X_missing = interpolated_df[missing_rows][columns]
    predicted_values = model.predict(X_missing)

    # Fill missing values with predicted values
    interpolated_df.loc[missing_rows, target_column] = predicted_values

    return interpolated_df
