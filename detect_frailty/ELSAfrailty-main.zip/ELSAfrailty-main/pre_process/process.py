from typing import Union, List, Dict

import pandas as pd

from pre_process.missing_value_imputation import proportion_null
from utils.utils import read_csv_cols, check_col_existence, split_string, get_value_by_row_value


def parse_coding(coding: str) -> Union[List, Dict]:
    """
    Parse a coding string into a list or dictionary based on specified rules.

    Args:
        coding (str): The coding string to decode.

    Returns:
        Union[List, Dict]: Either a list or a dictionary based on the decoding rules.
        If return List, It has two values: [lower, upper]
    """
    result = []
    # Split the coding string into individual rules
    rule_list = split_string(coding)

    if not rule_list:
        return result

    if rule_list.__len__() == 1:
        # If the coding string contains '-' delimiter, split it and return a list of float values
        if '-' in coding:
            s = split_string(coding, '-')
            return [float(x.strip()) for x in s]
    else:
        for rule in rule_list:
            if '=' in rule:
                maps = split_string(rule, separator="=")
                result.append((maps[0].strip(), maps[1].strip()))
            else:
                print(">> Not using the equal sign as a relational assignment.")
                return {}
        return dict(result)


def data_imputation(df: pd.DataFrame):
    # Let's check the percentage of the missing values in the dataset
    null_proportion = proportion_null(df, 'Variable Name')
    print(df.describe().T)
    print(df.info())


if __name__ == '__main__':
    description_path = "../csv/ELSAfrailty_dictionary.csv"
    search_col = "Variable Name"
    coding_rule = "Coding"
    target_list = [search_col, coding_rule]
    if check_col_existence(description_path, target_list):
        description_df = read_csv_cols(description_path, ["Variable Name", "Coding"])
        data_imputation(description_df)
        description_df.info()
        print(description_df.duplicated().sum())
        print(description_df.isnull().sum())
        var = get_value_by_row_value(description_df,
                                     column_to_search=search_col,
                                     value_to_search="frail_cat6",
                                     column_to_return=coding_rule)
        print(var)
        print(parse_coding(var))
