import os
from typing import List, Any, Union

import pandas as pd
from pandas import DataFrame


def read_csv(file_path: str,
             num_rows: int = 10) -> DataFrame:
    """
    Read the first few rows of a CSV file.

    Args:
        file_path (str): The path to the CSV file.
        num_rows (int): The number of rows to read from the CSV file. Default is 10.

    Returns:
        DataFrame: A DataFrame containing the read data.
    """
    return pd.read_csv(file_path, nrows=num_rows)


def read_csv_cols(file_path: str, target_cols: List[str]) -> DataFrame:
    """
    Read a CSV file and extract only the specified columns.

    Args:
        file_path (str): The path to the CSV file.
        target_cols (List[str]): A list of column names to extract.

    Returns:
        pd.DataFrame: A DataFrame containing only the specified columns.
    """
    return pd.read_csv(file_path, usecols=target_cols, encoding='latin1')


def check_col(df: DataFrame,
              col_name: str) -> bool:
    """
    Check if a column exists in the DataFrame.

    Args:
        df (DataFrame): The DataFrame to check.
        col_name (str): The name of the column to search for.

    Returns:
        bool: True if the column exists, False otherwise.
    """
    if col_name in df.columns:
        return True
    else:
        print(f">> Column {col_name} cannot be found in the df.")
        return False

def split_string(txt: str,
                 separator: str = ",") -> List[str]:
    """
    Split a string into a list of substrings using the specified separator.

    Args:
        txt (str): The input string to split.
        separator (str, optional): The separator used to split the string. Defaults to ",".

    Returns:
        List[str]: A list of substrings after splitting the input string.
    """
    return txt.split(separator)


def find_index_by_value(df: DataFrame,
                        column_name: str,
                        value_to_find: str) -> Union[int, None]:
    """
    Find the index of a specific value in the specified column of a DataFrame.

    Args:
        - df: DataFrame, the DataFrame to search.
        - column_name: str, the name of the column to search the value in.
        - value_to_find: The value to search for.

    Returns:
        If the matching value is found, return its index; otherwise, return None.
    """
    try:
        index_of_value = df.index[df[column_name] == value_to_find][0]
        return index_of_value
    except IndexError:
        return None


def get_value_by_row_value(df: DataFrame, column_to_search: str, value_to_search: any, column_to_return: str) -> any:
    """
    Determine the row index based on a value in a specific column, and then retrieve the value of another column in the same row.

    Args:
        df (pd.DataFrame): The DataFrame to search.
        column_to_search (str): The name of the column to search for the value.
        value_to_search (any): The value to search for in the specified column.
        column_to_return (str): The name of the column from which to retrieve the value.

    Returns:
        any: The value of the specified column in the row where the value is found.
    """
    # Determine the row index based on a value in a specific column
    row_index = df.loc[df[column_to_search] == value_to_search].index[0]

    # Retrieve the value of another column in the same row
    value = df.loc[row_index, column_to_return]

    return value


def check_col_existence(csv_file: str,
                        col_name: Union[str, List[str]]) -> bool:
    """
    Check if columns exist in a CSV file.

    Args:
        csv_file (str): The path to the CSV file.
        col_name (Union[str, List[str]]): Either a single column name (str) or a list of column names to check.

    Returns:
        bool: True if all columns exist, False otherwise.
    """
    if os.path.exists(csv_file):
        df = pd.read_csv(csv_file, encoding='latin1')
        if isinstance(col_name, str):
            return check_col(df, col_name)
        elif isinstance(col_name, List):
            for col in col_name:
                if not check_col(df, col):
                    return False
            return True
        else:
            print(">> The type of col_name can only be str | List.")
            return False
    else:
        print(f">> {csv_file}: File not found.")
        return False

